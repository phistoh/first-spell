#define gbuffers_line

uniform sampler2D texture;

in vec2 texUV;
in vec4 glColor;

void main() {
   vec4 color = texture2D(texture, texUV) * glColor;

   gl_FragData[0] = color;
}