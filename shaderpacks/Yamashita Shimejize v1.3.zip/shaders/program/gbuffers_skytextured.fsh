#define gbuffers_skytextured

#include "/common/math.glsl"

uniform float rainStrength;

uniform sampler2D texture;
uniform float viewWidth, viewHeight;

in vec2 texUV;
flat in vec4 glColor;

vec3 applyBlur(vec2 coord, vec2 direction) {
  const float weights[9] = float[](
    0.10855, 0.13135, 0.10406, 0.07216, 0.04380, 
    0.02328, 0.01083, 0.00441, 0.00157
  );

  vec2 texelSize = 1.0 / vec2(viewWidth, viewHeight);
  vec3 result = vec3(0.0);
  
  for (int i = 0; i < 9; ++i) {
    result += texture2D(texture, coord + direction * texelSize * float(i)).rgb * weights[i];
    if (i > 0) {
      result += texture2D(texture, coord - direction * texelSize * float(i)).rgb * weights[i];
    }
  }
  
  return result / 2;
}

void main() {
  vec4 color = texture2D(texture, texUV);
  color.rgb *= glColor.rgb;

  // Apply blur
  vec3 blur = vec3(0.0);

  blur += applyBlur(texUV, vec2(8.0, 8.0));
  blur += applyBlur(texUV, vec2(8.0, -8.0));

  color.rgb += blur;
  
  // Apply dithering
  float dither = bayer4(gl_FragCoord.xy / 2.0);
  color.rgb = floor(color.rgb * 12.0 + dither) / 12.0;

  color *= 1.0 - rainStrength;

  /* DRAWBUFFERS:0 */
  gl_FragData[0] = color;
}