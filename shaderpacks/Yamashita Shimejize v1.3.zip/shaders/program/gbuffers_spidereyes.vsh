#define gbuffers_spidereyes

out vec2 texcoord;
out vec4 glColor;

void main() {
  gl_Position = ftransform();

  texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
  glColor = gl_Color;
}