#define gbuffers_line

uniform float viewWidth, viewHeight;

uniform mat4 gbufferModelView;
uniform mat4 gbufferModelViewInverse;

out vec2 texUV;
out vec4 glColor;

void main() {
   const mat4 VIEW_SCALE = mat4(mat3(1.0 - (1.0 / 256.0)));
   float lineWidth = 3.0;

   vec2 screenSize = vec2(viewWidth, viewHeight);
   vec4 linePosStart = projectionMatrix * VIEW_SCALE * modelViewMatrix * vec4(vaPosition, 1.0);
   vec4 linePosEnd = projectionMatrix * VIEW_SCALE * modelViewMatrix * (vec4(vaPosition + vaNormal, 1.0));
   vec3 ndc1 = linePosStart.xyz / linePosStart.w;
   vec3 ndc2 = linePosEnd.xyz / linePosEnd.w;
   vec2 lineScreenDirection = normalize((ndc2.xy - ndc1.xy) * screenSize);
   vec2 lineOffset = vec2(-lineScreenDirection.y, lineScreenDirection.x) * lineWidth / screenSize;

   if (lineOffset.x < 0.0) lineOffset *= -1.0;
   if (gl_VertexID % 2 == 0) gl_Position = vec4((ndc1 + vec3(lineOffset, 0.0)) * linePosStart.w, linePosStart.w);
   else gl_Position = vec4((ndc1 - vec3(lineOffset, 0.0)) * linePosStart.w, linePosStart.w);

   glColor = gl_Color;
   texUV = (gl_TextureMatrix[0] * gl_MultiTexCoord0).st;
}