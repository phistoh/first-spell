#define gbuffers_skytextured

out vec2 texUV;

flat out vec4 glColor;

void main() {
  gl_Position = ftransform();
  texUV = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;

  glColor = gl_Color;
}