#define gbuffers_skybasic

#include "/shader.h"

uniform vec3 cameraPosition;

uniform mat4 gbufferModelView;
uniform mat4 gbufferModelViewInverse;
uniform mat4 gbufferProjectionInverse;

uniform sampler2D texture;
uniform sampler2D noisetex;

uniform int   worldDay;
uniform int   bedrockLevel;
uniform int   frameCounter;
uniform float frameTimeCounter;

uniform float viewWidth, viewHeight;
uniform float rainStrength;
uniform int   isEyeInWater;
uniform vec3  fogColor;
uniform float isCold;

in vec4     glColor;
in float    alpha;
in vec3     upVec;
in vec3     texUV;
flat in int time;

#include "/common/math.glsl"
#include "/common/getAurora.fsh"

void main() {
    const int bands = 4; // Number of bands
    
    float fog = (isEyeInWater > 0)
                ? 1.0 - exp(-gl_FogFragCoord * gl_Fog.density)
                : clamp((gl_FogFragCoord - gl_Fog.start) * gl_Fog.scale, 0.0, 1.0);
    
    float bandSize = 1.0 / float(bands);
    float currentBand = floor(fog * float(bands)) * bandSize;
    
    // Calculate normalized position within current band
    float posInBand = (fog - currentBand) / bandSize;
    
    // Get dither pattern (0-0.9375 in 16 steps)
    float dither = bayer4(gl_FragCoord.xy / 2.0);
    
    // Apply threshold (replaces the modulo check)
    float nextBand = currentBand + (posInBand > dither ? bandSize : 0.0);
    
    // Final color with perfect band transitions
    vec4 finalColor = mix(glColor, vec4(fogColor, glColor.a), nextBand);

		// Viewpos
		vec2 screenUV = gl_FragCoord.xy / vec2(viewWidth, viewHeight);
		vec4 clipPos = vec4(screenUV * 2.0 - 1.0, 1.0, 1.0);
		vec4 viewPos = gbufferProjectionInverse * clipPos;
		viewPos /= viewPos.w;

		// Stars
		finalColor.rgb += getStars(viewPos.xyz);

    // Aurora
    #if ENABLE_AURORA > 0
			
			vec3 aurora = floor(getAurora(viewPos.xyz, dither) * 4.0 + dither) / 4.0;
			finalColor.rgb += aurora * (1.0 - fog);

    #endif

		/* DRAWBUFFERS:0 */
    gl_FragData[0] = vec4(finalColor.rgb, alpha);
    gl_FragData[1] = vec4(0.0);
}