#define gbuffers_skybasic

#include "/shader.h"

uniform mat4 gbufferModelView;
uniform mat4 gbufferModelViewInverse;

uniform float timeAngle;
uniform int   worldTime;

uniform int renderStage;

out float    alpha;
out vec4     glColor;
out vec3     upVec;
out vec2     texUV;
flat out int time;

#ifndef MC_RENDER_STAGE_MOON
#define MC_RENDER_STAGE_MOON 1
#endif

void main() {
   time = worldTime;

   vec3 position = (gl_ModelViewMatrix * gl_Vertex).xyz;
   position = (gbufferModelViewInverse * vec4(position, 1.0)).xyz;

   gl_Position = gl_ProjectionMatrix * gbufferModelView * vec4(position, 1.0);
   gl_FogFragCoord = length(position);

   texUV = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
   upVec = normalize(gbufferModelView[1].xyz);

   glColor = gl_Color;

   alpha = 1.0;

   #if MC_VERSION >= 11605
      if (renderStage == MC_RENDER_STAGE_STARS) {
         alpha = 0.0;
      }
      #else
      if (gl_Color.r == gl_Color.g && gl_Color.g == gl_Color.b && gl_Color.r > 0.0) {
         alpha = 0.0;
      }
	#endif

   // remove vanilla sunset gradient
	if (renderStage == MC_RENDER_STAGE_MOON) {
		alpha = 0.0;
	}
}