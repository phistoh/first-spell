#version 330 compatibility

#include "shader.h"

uniform sampler2D colortex0;
uniform float viewWidth, viewHeight;
uniform float frameTimeCounter;

in vec2 texcoord;

#include "/common/math.glsl"

// Stepped ping-pong twinkle effect
float getTwinkleFactor() {
    float speed = 1.0; // Animation speed
    float steps = 3.0; // Number of steps in each direction
    
    // Create ping-pong progress
    float pingpong = abs(fract(frameTimeCounter * speed * 0.5) * 2.0 - 1.0);
    
    // Quantize into steps
    float stepped = floor(pingpong * steps) / (steps - 1.0);
    
    // Map to brightness range (0.1 to 0.2)
    return mix(0.1, 0.2, stepped);
}

float getWarmthFactor(vec3 color) {
    float warmth = color.r * max(color.r - color.b, 0.0) * 3.0;
    return clamp(warmth, 0.0, 2.0);
}

vec3 extractWarmBloom(vec2 coord) {
    vec3 color = texture2D(colortex0, coord).rgb;
    float warmth = getWarmthFactor(color);
    if (warmth < 0.1) return vec3(0.0);
    
    float brightness = dot(color, vec3(0.2126, 0.7152, 0.0722));
    vec3 bloom = max(color - 0.6, 0.0);
    return bloom * bloom * (5.0 * warmth);
}

vec3 applyBlur(vec2 coord, vec2 direction) {
    const float weights[9] = float[](
        0.10855, 0.13135, 0.10406, 0.07216, 0.04380, 
        0.02328, 0.01083, 0.00441, 0.00157
    );

    vec2 texelSize = 1.0 / vec2(viewWidth, viewHeight);
    vec3 result = vec3(0.0);
    
    for (int i = 0; i < 9; ++i) {
        result += extractWarmBloom(coord + direction * texelSize * float(i)) * weights[i];
        if (i > 0) {
            result += extractWarmBloom(coord - direction * texelSize * float(i)) * weights[i];
        }
    }
    
    return result * 3.0;
}

void main() {
    vec3 color = texture2D(colortex0, texcoord).rgb;

    #if ENABLE_BLOOM > 0

      vec3 bloom = vec3(0.0);
      
      // Apply blur passes
      bloom += applyBlur(texcoord, vec2(4.0, 4.0));
      bloom += applyBlur(texcoord, vec2(4.0, -4.0));
      
      // Apply dithering
      float dither = bayer4(gl_FragCoord.xy / 2.0);
      bloom = floor(bloom * 2.0 + dither) / 2.0;
      
      // Apply stepped twinkle
      float twinkle = getTwinkleFactor();
      bloom *= twinkle;
      
      color += bloom;

    #endif
    
    gl_FragData[0] = vec4(color, 1.0);
    gl_FragData[1] = vec4(0.0);
}