
#if IS_THE_NETHER == 1

	void main() {

		discard;
		return;
		
	}

#else

	uniform sampler2D lightmap;
	uniform sampler2D texture;

	varying vec2 lmcoord;
	varying vec2 texcoord;
	varying vec4 glcolor;


	void main() {

		vec4 color = texture2D(texture, texcoord) * glcolor;
		color.rgb=color.a > 254.6/255.?vec3(1.):color.rgb;
		gl_FragData[0] = color;

		
	}

#endif
	
	
